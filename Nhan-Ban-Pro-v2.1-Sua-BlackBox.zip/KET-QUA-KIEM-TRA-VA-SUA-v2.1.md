# Nhân Bản Pro v2.1 — Kết quả kiểm tra zip và các lỗi đã sửa

Bản này sửa từ đúng file zip bạn gửi (`android-studio-apk-builder_0_tu3z.zip`).
Phiên bản mới: **2.1.0 (versionCode 3)**. File APK cũ 22 MB trong zip đã bỏ đi
vì nó không build được từ chính mã nguồn trong zip đó — cài APK cũ vào thì
vẫn là bản lỗi cũ.

## 1. Các lỗi tìm được (có bằng chứng trong code)

### Lỗi A — Zip thiếu 185 file + thư mục `res/` của BlackBox nên KHÔNG build được
- `blackbox/Bcore` trong zip chỉ có 419 file, trong khi bản gốc
  ALEX5402/NewBlackbox có 609 file. Thiếu hẳn: `fake/delegate`,
  `fake/frameworks`, `fake/hook`, `fake/provider`, `fake/service`,
  `proxy/`, `util/`, `utils/`, `jnihook/` và toàn bộ `src/main/res/`
  (trong đó có chuỗi `black_box_service_name` mà `BlackBoxCore` dùng để
  nhận diện tiến trình máy chủ).
- Code còn lại trong zip vẫn `import top.niunaijun.blackbox.utils.*`,
  `proxy.*`, `fake.provider.*`... nên Gradle sẽ báo hàng trăm lỗi
  "cannot find symbol" ngay khi biên dịch.
- `settings.gradle.kts` khai thêm 2 module `:black-reflection` và
  `:compiler` nhưng 2 thư mục này cũng không có trong zip, trong khi
  `blackbox/Bcore/build.gradle` lại phụ thuộc vào cả hai
  (`implementation(project(":black-reflection"))`,
  `annotationProcessor(project(":compiler"))`).
- **Đã sửa:** khôi phục đủ 185 file + `res/` từ đúng fork
  ALEX5402/NewBlackbox, khôi phục nguyên 2 module `black-reflection` và
  `compiler`. Chỉ giữ lại file `blackbox/Bcore/build.gradle` của bạn (đã
  sửa cho AGP 9), không ghi đè bằng bản gốc.

### Lỗi B — Facebook màn hình đen: app Play Store là split APK, BlackBox chỉ cài base.apk
- `BlackBoxCore.installPackageAsUser(packageName, userId)` chỉ truyền
  `applicationInfo.sourceDir` (base.apk) cho engine, bỏ qua
  `splitSourceDirs`. `BPackage` cũng không có trường nào lưu split,
  `CopyExecutor` chỉ copy base, `generateApplicationInfo` chỉ gán
  `sourceDir` từ base. Facebook, Muse AI bản Play Store đều là split APK
  (base + `split_config.arm64_v8a` chứa lib native + `split_config.xxhdpi`
  chứa tài nguyên...). Thiếu split thì app mở lên thiếu tài nguyên, thiếu
  lib native nên đen màn hình / văng. App nhẹ là APK đơn nên vẫn chạy —
  đúng y triệu chứng bạn gặp.
- **Đã sửa (trong engine):** `BPackage` thêm `splitNames`/`splitCodePaths`
  (lưu cuối Parcel để bản sao cũ v2.0 vẫn đọc được); khi cài từ máy,
  engine tự lấy split từ `ApplicationInfo` của máy; `CopyExecutor` copy
  từng split vào thư mục ảo (`data/app/<gói>/split_<tên>.apk`), copy cả
  native lib trong split, rồi đổi đường dẫn sang file ảo;
  `PackageManagerCompat.generateApplicationInfo` gán `splitSourceDirs` /
  `splitPublicSourceDirs` trỏ tới split ảo; `BPackageManagerService` kiểm
  chứng sau khi cài — máy gốc có split mà bản ảo có 0 split thì báo lỗi
  cài đặt rõ ràng thay vì tạo bản sao đen màn hình.

### Lỗi C — Muse AI kẹt ở logo: trong bản sao chưa hề có Google Play Services
- Code không gọi `installGms()` ở đâu cả, dù `BlackBoxCore` đã có sẵn
  `isSupportGms()` / `isInstallGms()` / `installGms()`. Muse AI chờ Play
  Services nên đứng ở logo.
- **Đã sửa:** `BlackBoxEngine.prepareClone` tự cài GMS 1 lần cho mỗi
  virtual user mới (best-effort: cài không được thì vẫn cho tạo bản sao để
  app không cần Google vẫn chạy, nhưng hiện cảnh báo lên màn hình).
  Lưu ý thật: GMS cũng là app split nên trước đây có cài cũng dễ lỗi —
  giờ đã có sửa split ở Lỗi B hỗ trợ.

### Lỗi D — DaemonService bị tắt nên tiến trình máy chủ chết khi app vào nền
- `NhanBanApplication` để `isEnableDaemonService() = false`. Bản demo gốc
  của BlackBox để mặc định true. Không có daemon giữ sống, tiến trình máy
  chủ `:black` bị hệ thống giết khi Nhân Bản Pro vào nền, bản sao đang chạy
  bị văng, mở lại chỉ thấy đen.
- **Đã sửa:** bật lại `true`, khai thêm quyền `FOREGROUND_SERVICE` và
  `FOREGROUND_SERVICE_SPECIAL_USE` trong manifest của app.

### Lỗi E — App nuốt hết lỗi khởi tạo rồi báo "Đã kết nối" giả
- `attachBaseContext` có 4 khối `catch (_: Throwable) {}` rỗng, và
  `onCreate` gọi `markReadyFromDirectInit()` ngay cả khi attach đã hỏng.
  Người dùng thấy banner "Đã kết nối" trong khi engine chưa chạy.
- **Đã sửa:** lỗi attach được lưu lại và `onCreate` báo `InitFailed` với
  đúng lý do; chỉ khi `doAttachBaseContext` + `doCreate` đều xong mới báo
  `Ready`. Các lỗi bỏ qua được (closeCodeInit...) vẫn chỉ ghi log.

### Lỗi F — Tạo ra bản sao "chết" rồi mới báo lỗi khi mở
- `BlackBoxEngine.prepareClone` bỏ qua kết quả `createUser()` /
  `installPackageAsUser()`, và khi engine `NotIntegrated`/`InitFailed`
  vẫn trả `Result.success` nên `CloneRepository` lưu bản sao vào danh
  sách. Bấm mở mới biết là bản sao chết.
- **Đã sửa:** lỗi nào cũng chặn tạo bản sao và trả đúng lý do; sau khi cài
  còn kiểm chứng split (máy gốc có split mà bản ảo 0 split thì xóa dấu
  vết và báo lỗi, gợi ý dùng bản APK đơn như Facebook Lite). Unit test cũ
  `ExampleUnitTest` đã sửa theo hành vi mới (prepare phải thất bại khi
  chưa tích hợp).

### Lỗi G — Chưa từng xin quyền "Tất cả các tệp", mở bản sao lần đầu hay trả false
- `BlackBoxCore.launchApk` trên Android 11+ yêu cầu All Files Access,
  app không đăng ký `AppLifecycleCallback.onStoragePermissionNeeded` và
  không xin quyền này ở đâu. App con mở lên lỗi file âm thầm. Ngoài ra
  lần mở đầu tiên tiến trình `:black` chưa ấm nên `launchApk` hay trả
  `false` ngay.
- **Đã sửa:** đăng ký callback — engine cần quyền thì chặn lần mở đó và
  hiện hướng dẫn cấp quyền; `launchClone` kiểm tra quyền trước khi mở và
  thử lại 1 lần sau 1,5 giây nếu lần đầu trả false. Manifest khai thêm
  `QUERY_ALL_PACKAGES` (đọc `sourceDir`/`splitSourceDirs` của app khác
  trên Android 11+), `MANAGE_EXTERNAL_STORAGE`, `REQUEST_INSTALL_PACKAGES`.

### Lỗi H — Build cũng sẽ fail vì thiếu `gradlew` và plugin library
- Zip không có `gradlew` / `gradlew.bat`, `build.gradle.kts` gốc không khai
  plugin `com.android.library` mà `:Bcore` cần, và bản debug trỏ tới file
  `debug.keystore` không có trong zip.
- **Đã sửa:** thêm `gradlew` + `gradlew.bat`, thêm plugin
  `android-library` vào catalog + root build, bản debug chỉ dùng
  `debugConfig` khi file keystore thật sự tồn tại (không có thì Gradle
  dùng debug key mặc định).

## 2. Cách build bản mới (không cần máy tính)

Trong zip này đã có sẵn file `.github/workflows/build-apk.yml`:
1. Đẩy toàn bộ nội dung zip này lên GitHub (ghi đè repo cũ).
2. Vào tab **Actions** → **Build NhanBanPro APK** → **Run workflow**.
3. Đợi chạy xanh, tải APK ở mục **Artifacts** (`NhanBanPro-v2.1.0-debug`).
4. Trên điện thoại: **gỡ hẳn Nhân Bản Pro cũ** (bản sao cũ dùng định dạng
   lưu trữ cũ, không tương thích split mới — phải tạo lại từ đầu), rồi
   cài APK mới.

## 3. Cách test sau khi cài (làm đúng thứ tự)

1. Mở app, kiểm tra banner hiện **"BlackBox: Đã kết nối"** thật (nếu báo
   khởi tạo lỗi thì chụp màn hình dòng lỗi gửi lại — giờ lỗi đã hiện rõ
   lý do, không còn báo Ready giả).
2. Cấp quyền **"Truy cập tất cả các tệp"**: Cài đặt hệ thống > Ứng dụng >
   Nhân Bản Pro > Quyền. Nếu chưa cấp, lần mở bản sao đầu tiên app sẽ
   hiện hướng dẫn.
3. Tạo bản sao Facebook 1 → mở → đăng nhập tài khoản A. **Lần đầu chờ đủ
   60 giây ở màn hình đen/logo, đừng bấm quay lại** (khởi động trong
   không gian ảo rất chậm, GMS đang cài nền).
4. Tạo Facebook 2 → đăng nhập tài khoản B → kiểm tra Facebook 1 vẫn là A,
   đăng xuất Facebook 1 rồi mở Facebook 2 vẫn còn B.
5. Tạo bản sao Muse AI → mở → nếu vẫn kẹt ở logo sau 60 giây thì đó là
   app phát hiện môi trường ảo (xem mục 4), dùng bản web của Muse AI
   trong trình duyệt sẽ ổn hơn.

## 4. Giới hạn còn lại — nói thẳng để bạn khỏi mất công thử đi thử lại

- **Muse AI có thể vẫn không chạy được trong không gian ảo** dù đã có GMS
  và split: một số app kiểm tra môi trường ảo / Play Integrity và từ chối
  chạy. Đây là giới hạn của chính BlackBox (engine 2022, hỗ trợ chính
  thức tới Android 12), không phải do bạn làm sai. Bản v2.1 đã làm hết
  phần sửa được ở phía mình (GMS + split + daemon + quyền).
- **Facebook bản Play Store** sau sửa split có tỉ lệ chạy được cao hơn
  nhiều, nhưng nếu vẫn đen màn hình thì dùng **Facebook Lite** (APK đơn,
  nhẹ, không split) là phương án chắc chắn nhất.
- **Không dùng bản sao cho app ngân hàng / ví tiền.**
- Mỗi bản sao nặng ~300 MB + GMS, chỉ mở 1–2 bản sao cùng lúc.
- Lần đầu build trên GitHub có thể vẫn đỏ ở 1 bước khác (vd AGP 9.1.1
  với Bcore cũ): nếu đỏ, chụp màn hình bước đỏ gửi lại, mình sửa tiếp
  theo đúng lỗi đó — đừng tự sửa lung tung nhiều chỗ cùng lúc.

## 5. File đã thay đổi trong zip v2.1

- `blackbox/Bcore/src/main/java/.../BPackage.java` — thêm splitNames/splitCodePaths + Parcel.
- `blackbox/Bcore/.../BEnvironment.java` — thêm `getSplitApkFile()`.
- `blackbox/Bcore/.../installer/CopyExecutor.java` — copy split + native lib.
- `blackbox/Bcore/.../PackageManagerCompat.java` — gán splitSourceDirs ảo.
- `blackbox/Bcore/.../BPackageManagerService.java` — kiểm chứng split sau cài.
- `blackbox/Bcore/.../BlackBoxCore.java` — log số split khi cài.
- `blackbox/black-reflection/`, `blackbox/compiler/` — khôi phục nguyên module.
- `blackbox/Bcore/src/main/res/` + 185 file engine — khôi phục từ fork ALEX5402/NewBlackbox.
- `app/.../NhanBanApplication.kt` — Daemon true, không nuốt lỗi, callback quyền file.
- `app/.../data/BlackBoxBridge.kt` — quyền All Files, đếm split, GMS, cài từ file APK.
- `app/.../data/BlackBoxEngine.kt` — chặn tạo bản sao chết, kiểm chứng split, cài GMS, thử mở lại.
- `app/.../ui/MainViewModel.kt` — hiện cảnh báo quyền file / GMS.
- `app/src/main/AndroidManifest.xml` — thêm quyền QUERY_ALL_PACKAGES, MANAGE_EXTERNAL_STORAGE, REQUEST_INSTALL_PACKAGES, FOREGROUND_SERVICE.
- `app/build.gradle.kts` — version 2.1.0, sửa ký debug khi thiếu keystore.
- `build.gradle.kts`, `gradle/libs.versions.toml` — thêm plugin `com.android.library`.
- `gradlew`, `gradlew.bat`, `.github/workflows/build-apk.yml` — mới, để build trên GitHub.
- `app/src/test/.../ExampleUnitTest.kt` — sửa test theo hành vi mới.
