pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "NhanBanPro"
include(":app")

// BẢN 2.0 — TÍCH HỢP BLACKBOX (làm trên máy tính, xem HUONG-DAN-TICH-HOP-BLACKBOX.md):
// Sau khi bạn đã chép thư mục BlackBox vào trong project này (thư mục
// "blackbox" nằm cùng cấp với "app"), bỏ comment 2 dòng dưới đây và
// bỏ comment dòng implementation(project(":blackbox:Bcore")) trong
// app/build.gradle.kts, rồi Sync lại Gradle.
// include(":blackbox:Bcore")
// include(":blackbox:black")
