# Tích hợp BlackBox — bước bắt buộc để bản sao chạy độc lập thật

Bản 2.0 đã viết sẵn toàn bộ code gọi BlackBox (BlackBoxBridge,
BlackBoxEngine, NhanBanApplication). Nhưng BlackBox là một engine
lớn, có code native (C/C++), phân biệt bản 32-bit / 64-bit, nên
**không thể nhét sẵn vào file ZIP này**. Bạn phải thêm nó vào
project trên máy tính, làm một lần duy nhất theo các bước dưới đây.

> Nếu bạn bỏ qua bước này mà build APK luôn, app vẫn mở được,
> vẫn tạo được bản sao không giới hạn, nhưng khi chạm để mở bản sao
> app sẽ báo "Chưa tích hợp BlackBox" và KHÔNG mở app gốc — để
> tránh lặp lại lỗi bản 1.0 (mở app gốc chung tài khoản, thoát một
> cái là thoát hết).

## 0. Bạn cần gì

- Máy tính + Android Studio (bản mới nhất) + mạng.
- Điện thoại Android 8.0 trở lên. BlackBox hỗ trợ chính thức
  Android 5.0–12.0; tác giả khuyên targetSdk <= 28 để tương thích
  tốt nhất. Trên Android 13/14, một số app có thể chạy không ổn
  hoặc tự văng — hãy test trước với 2 bản sao Facebook (mục 4).
- Biết điện thoại mình là 32-bit hay 64-bit: BlackBox có 2 bản
  demo riêng. Nếu trong danh sách app để nhân bản không thấy app
  bạn cần, hãy thử build bản còn lại.

## 1. Lấy mã nguồn BlackBox

Trên máy tính, mở Terminal / Command Prompt, vào thư mục cha của
project Nhân Bản Pro, chạy:

```
git clone https://github.com/FBlackBox/BlackBox.git
```

Bạn sẽ có thư mục `BlackBox` nằm cạnh thư mục `NhanBanPro-v2`.
Trong đó có 2 module quan trọng: `Bcore` (engine) và `black`
(daemon giữ engine chạy nền).

## 2. Thêm BlackBox vào project

1. Chép (copy) toàn bộ thư mục `BlackBox` vừa tải về vào trong
   thư mục project `NhanBanPro-v2`, rồi đổi tên thành `blackbox`
   (chữ thường, không dấu).
   Kết quả: trong `NhanBanPro-v2` có 2 thư mục con: `app` và `blackbox`.
2. Mở file `settings.gradle.kts` trong project, bỏ comment 2 dòng:
   ```
   include(":blackbox:Bcore")
   include(":blackbox:black")
   ```
3. Mở file `app/build.gradle.kts`, bỏ comment dòng:
   ```
   implementation(project(":blackbox:Bcore"))
   ```
4. Mở Android Studio → Open → chọn thư mục `NhanBanPro-v2` →
   Trust Project → đợi Gradle sync xong.
   **Lần đầu build, bấm Build → Make Project một lần trước**,
   theo hướng dẫn của BlackBox — nếu không, app nhân bản có thể
   bị văng ngay khi mở.

## 3. Khởi tạo BlackBox — 2 cách

### Cách A (mặc định, đã có sẵn trong code): reflection

File `NhanBanApplication.kt` đã gọi BlackBox qua `BlackBoxBridge`
bằng reflection. Nếu sau khi sync mà app chạy và màn hình chính
hiện **"BlackBox: Đã kết nối — bản sao chạy độc lập"** thì xong,
không cần làm gì thêm.

### Cách B (dùng khi Cách A báo "Khởi tạo lỗi")

Một số bản BlackBox định nghĩa `ClientConfiguration` là abstract
class, không tạo được bằng Proxy. Khi đó thay thân 2 hàm trong
`NhanBanApplication.kt` bằng code trực tiếp dưới đây (đây là code
mẫu trong README chính thức của BlackBox, chỉ đổi tên package
thành `com.nhanban.pro`):

```kotlin
package com.nhanban.pro

import android.app.Application
import android.content.Context
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackbox.app.configuration.ClientConfiguration

class NhanBanApplication : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        try {
            BlackBoxCore.get().doAttachBaseContext(base, object : ClientConfiguration() {
                override fun getHostPackageName(): String {
                    return base.packageName
                }
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onCreate() {
        super.onCreate()
        BlackBoxCore.get().doCreate()
    }
}
```

> Nếu Android Studio báo không tìm thấy `ClientConfiguration` ở
> package trên, hãy tìm file `ClientConfiguration` trong module
> `blackbox` bạn vừa chép vào và sửa lại `import` cho đúng với
> bản BlackBox bạn tải về. Tên hàm `doAttachBaseContext`,
> `doCreate`, `installPackageAsUser`, `launchApk`, `createUser`,
> `deleteUser` là tên trong README chính thức, không đổi.

## 4. Build APK và test độc lập — BẮT BUỘC làm trước khi dùng thật

1. Build → Build App Bundle(s) / APK(s) → Build APK(s).
   File APK ở `app/build/outputs/apk/debug/app-debug.apk`.
2. Chép APK sang điện thoại, bật "Cho phép cài đặt ứng dụng
   không rõ nguồn gốc", rồi cài.
3. Mở Nhân Bản Pro, kiểm tra màn hình chính hiện
   "BlackBox: Đã kết nối".
4. **Test độc lập (làm đúng 5 bước này):**
   - Tạo Facebook 1 → mở → đăng nhập tài khoản A.
   - Tạo Facebook 2 → mở → đăng nhập tài khoản B (khác A).
   - Mở Facebook 1, kiểm tra vẫn là tài khoản A.
   - Trong Facebook 1, bấm Đăng xuất → thoát hẳn.
   - Mở Facebook 2, kiểm tra vẫn còn đăng nhập tài khoản B.
   - Nếu Facebook 2 vẫn còn B: **ĐẠT — bản sao đã độc lập thật.**
   - Nếu Facebook 2 cũng bị thoát: dừng lại, đừng dùng cho tài
     khoản quan trọng, và báo lại cho mình biết bạn test trên máy
     gì, Android mấy, app nào — để mình xem có phải do BlackBox
     không hỗ trợ máy đó không.
5. Chỉ tạo thêm bản sao khi test trên đã đạt. Mỗi bản sao nặng
   ~300 MB, tạo nhiều quá máy sẽ chậm, hết pin nhanh.

## 5. Giới hạn bạn cần biết trước

- **Không giới hạn số lượng trong code, nhưng có giới hạn thực tế:**
  dung lượng trống, RAM, pin. Chỉ mở 1–2 bản sao cùng lúc.
- **Một số app chặn môi trường ảo:** app ngân hàng, ví tiền,
  một số game chống gian lận có thể không đăng nhập được hoặc
  yêu cầu xác minh lại. **Không dùng bản sao cho app ngân hàng /
  ví tiền.**
- **Android 13/14:** BlackBox gốc (2022) hỗ trợ chính thức tới
  Android 12. Trên máy mới hơn, hãy test kỹ mục 4; nếu hay văng,
  thử máy Android 12 trở xuống hoặc tìm bản fork BlackBox mới hơn.
- **32-bit / 64-bit:** nếu app bạn cần không hiện trong danh sách
  để nhân bản, hãy build lại với bản BlackBox còn lại.
- **Xóa bản sao:** xóa trong Nhân Bản Pro sẽ xóa luôn virtual
  user và dữ liệu đăng nhập của bản sao đó. App gốc không bị ảnh
  hưởng. Xóa nhầm là mất tài khoản đăng nhập trong bản sao đó
  (phải đăng nhập lại).
