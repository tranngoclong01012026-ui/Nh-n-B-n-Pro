package top.niunaijun.blackbox.core.system.pm.installer;


import java.io.File;
import java.io.IOException;

import top.niunaijun.blackbox.core.env.BEnvironment;
import top.niunaijun.blackbox.core.system.pm.BPackageSettings;
import top.niunaijun.blackbox.entity.pm.InstallOption;
import top.niunaijun.blackbox.utils.FileUtils;
import top.niunaijun.blackbox.utils.NativeUtils;
import top.niunaijun.blackbox.utils.Slog;


public class CopyExecutor implements Executor {

    @Override
    public int exec(BPackageSettings ps, InstallOption option, int userId) {
        try {
            if (!option.isFlag(InstallOption.FLAG_SYSTEM)) {
                NativeUtils.copyNativeLib(new File(ps.pkg.baseCodePath), BEnvironment.getAppLibDir(ps.pkg.packageName));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
        if (option.isFlag(InstallOption.FLAG_STORAGE)) {
            
            File origFile = new File(ps.pkg.baseCodePath);
            File newFile = BEnvironment.getBaseApkDir(ps.pkg.packageName);
            try {
                if (option.isFlag(InstallOption.FLAG_URI_FILE)) {
                    boolean b = FileUtils.renameTo(origFile, newFile);
                    if (!b) {
                        FileUtils.copyFile(origFile, newFile);
                    }
                } else {
                    FileUtils.copyFile(origFile, newFile);
                }
                newFile.setReadOnly();
                
                ps.pkg.baseCodePath = newFile.getAbsolutePath();
            } catch (IOException e) {
                e.printStackTrace();
                return -1;
            }
        } else if (option.isFlag(InstallOption.FLAG_SYSTEM)) {

        }
        // v2.1 — split APK (lỗi gốc gây Facebook màn hình đen): trước đây chỉ
        // base.apk được cài, các split config (chứa tài nguyên theo dpi, lib
        // native arm64, ...) bị bỏ rơi nên app nặng mở lên thiếu tài nguyên.
        // Copy từng split vào thư mục ảo và đổi splitCodePaths sang đường dẫn
        // ảo; copy cả native lib trong split (vd split_config.arm64_v8a).
        // Lỗi copy 1 split -> fail cả lần cài để báo lỗi rõ, thay vì tạo ra
        // bản sao mở lên màn hình đen.
        if (ps.pkg.splitCodePaths != null && ps.pkg.splitNames != null) {
            try {
                for (int i = 0; i < ps.pkg.splitCodePaths.length; i++) {
                    String hostSplit = ps.pkg.splitCodePaths[i];
                    if (hostSplit == null) continue;
                    File hostFile = new File(hostSplit);
                    if (!hostFile.exists()) {
                        Slog.e("CopyExecutor", "Split APK không còn tồn tại: " + hostSplit);
                        return -1;
                    }
                    String splitName = (i < ps.pkg.splitNames.length && ps.pkg.splitNames[i] != null)
                            ? ps.pkg.splitNames[i] : ("split" + i);
                    File virtualSplit = BEnvironment.getSplitApkFile(ps.pkg.packageName, splitName);
                    FileUtils.copyFile(hostFile, virtualSplit);
                    virtualSplit.setReadOnly();
                    ps.pkg.splitCodePaths[i] = virtualSplit.getAbsolutePath();
                    try {
                        NativeUtils.copyNativeLib(virtualSplit, BEnvironment.getAppLibDir(ps.pkg.packageName));
                    } catch (Exception ignored) {
                        // Split không chứa native lib thì bỏ qua, không fail cài đặt.
                    }
                    Slog.d("CopyExecutor", "Đã copy split " + splitName + " -> " + virtualSplit.getAbsolutePath());
                }
            } catch (Exception e) {
                e.printStackTrace();
                return -1;
            }
        }
        return 0;
    }
}
