pluginManagement {
  repositories {
    maven { url = uri("https://www.jitpack.io") }
    google {
      content {
        includeGroupByRegex("com\\.android.*")
        includeGroupByRegex("com\\.google.*")
        includeGroupByRegex("androidx.*")
      }
    }
    mavenCentral()
    gradlePluginPortal()
  }
}

plugins { id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0" }

dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
  repositories {
    maven { url = uri("https://www.jitpack.io") }
    google()
    mavenCentral()
  }
}

rootProject.name = "NhanBanPro"

include(":app")
include(":Bcore")
project(":Bcore").projectDir = file("blackbox/Bcore")
include(":black-reflection")
project(":black-reflection").projectDir = file("blackbox/black-reflection")
include(":compiler")
project(":compiler").projectDir = file("blackbox/compiler")
